import React from 'react';
import './Navbar.css';

function Navbar() {
  return (
    <nav className="Navbar">
      <a href="https://en.wikipedia.org/wiki/The_Simpsons">Simpons Quotes</a>
    </nav>
  );
}

export default Navbar;
